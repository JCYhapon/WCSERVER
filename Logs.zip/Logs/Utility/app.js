var myLogModule = require('../Log');

myLogModule.info('NodeJS is currently running...');
