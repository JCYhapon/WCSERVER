module.export = function (firstName, lastName){
  this.firstName = firstName;
  this.lastName = lasNname;
  this.fullName = function () {
    return this.firstName + '' + this.lastName;
  }
}