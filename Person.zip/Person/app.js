var person = require('./Person.js');

var person1 = new person('James', 'Bond');

console.log(person1.fullName())